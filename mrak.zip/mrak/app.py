from flask import Flask, render_template, request, redirect

app = Flask(__name__)

# данные хранятся в памяти и при перезапуске сбрасываются
MOVIES = {
    1: {"id": 1, "title": "Шёпот леса", "year": 2025, "genre": "Фолк-хоррор",
        "rating": 7.6, "time": "1 ч 36 мин", "image": "f1.png",
        "desc": "Экспедиция уходит в глухой лес за старой легендой."},
    2: {"id": 2, "title": "За последней дверью", "year": 2024, "genre": "Сверхъестественное",
        "rating": 8.1, "time": "1 ч 52 мин", "image": "f2.png",
        "desc": "В старом доме есть коридор, которого нет на плане."},
    3: {"id": 3, "title": "Пустая колыбель", "year": 2024, "genre": "Мистика",
        "rating": 7.2, "time": "1 ч 44 мин", "image": "f3.png",
        "desc": "Каждую ночь колыбель в детской качается сама."},
    4: {"id": 4, "title": "Проклятие аббатства", "year": 2025, "genre": "Мистика",
        "rating": 7.8, "time": "1 ч 48 мин", "image": "baner.png",
        "desc": "Некоторые двери лучше не открывать."},
}
BANNER = [4, 2, 3]            # какие фильмы крутятся в баннере

user = "Алексей"
favorites = [1, 2, 3]         # id избранных фильмов
history = []                  # id просмотренных фильмов
notify = {"Новые премьеры": True, "Рекомендации": True}


# поиск, теги ,сортировка
def find_movies():
    q = request.args.get("q", "").lower()
    genre = request.args.get("genre", "")
    result = []
    for m in MOVIES.values():
        if q in m["title"].lower() and (genre == "" or m["genre"] == genre):
            result.append(m)
    if request.args.get("sort") == "rating":
        result.sort(key=lambda m: m["rating"], reverse=True)
    return result


# страницы
@app.route("/")
def index():
    slide = int(request.args.get("slide", 0)) % len(BANNER)
    return render_template("index.html", active="home", movies=find_movies(),
                           banner=MOVIES[BANNER[slide]], slide=slide,
                           favorites=favorites, user=user)


@app.route("/catalog")
def catalog():
    return render_template("catalog.html", active="catalog", movies=find_movies(), user=user)


@app.route("/movie/<int:id>")
def movie(id):
    return render_template("movie.html", active="catalog", m=MOVIES[id],
                           favorites=favorites, user=user)


@app.route("/watch/<int:id>")
def watch(id):
    if id not in history:
        history.append(id)
    return redirect("/movie/" + str(id) + "?watching=1")


@app.route("/favorites")
def favorites_page():
    return render_template("favorites.html", active="favorites",
                           movies=[MOVIES[i] for i in favorites], user=user)


@app.route("/favorite/<int:id>")       # добавить / убрать из избранного
def toggle_favorite(id):
    if id in favorites:
        favorites.remove(id)
    else:
        favorites.append(id)
    return redirect(request.referrer or "/")   # вернуться туда, откуда нажала


@app.route("/profile")
def profile():
    ratings = [MOVIES[i]["rating"] for i in history]
    average = round(sum(ratings) / len(ratings), 1) if ratings else "—"
    return render_template("profile.html", active="profile", user=user,
                           viewed=len(history), fav_count=len(favorites), average=average)


@app.route("/history")
def history_page():
    return render_template("history.html", active="profile",
                           movies=[MOVIES[i] for i in history], user=user)


@app.route("/notifications")
def notifications():
    return render_template("notifications.html", active="profile", notify=notify, user=user)


@app.route("/notifications/toggle")
def toggle_notify():
    name = request.args.get("name")
    notify[name] = not notify[name]
    return redirect("/notifications")


@app.route("/settings", methods=["GET", "POST"])
def settings():
    global user
    if request.method == "POST":
        user = request.form["name"] or user
        return redirect("/profile")
    return render_template("settings.html", active="profile", user=user)


@app.route("/logout")                  # «Выйти» - сбрасываются данные
def logout():
    global user
    user = "Алексей"
    favorites[:] = [1, 2, 3]
    history.clear()
    return redirect("/")


if __name__ == "__main__":
    app.run(debug=True)
